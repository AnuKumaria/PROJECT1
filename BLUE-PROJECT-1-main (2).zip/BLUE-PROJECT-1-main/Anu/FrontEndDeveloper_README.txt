FrontEndDeveloper README for Project One (CS400 @ UW Madison)
========================================================
Name of FrontEndDeveloper: Sydney Benck
@wisc.edu Email of FrontEndDeveloper: sbenck@wisc.edu
Group: GG
Team: blue
Files Written by Me:
--------------------
I wrote the MovieMapper class and it's purpose is to interact with the user
and utilize the backend interface. Depending on which keys the user inputs
determines which mode the class is in. There is a base mode, genre selection
mode, and a ratings mode. Each mode allows the user to scroll through the
list of movies based off of thier ratings or a corresponding number that was
assigned to the movie/genre.
Additional Contributions:
-------------------------
Attended meetings to discuss our progress on our code and put it all together.
My teammates were a great help to me when I was stumped on a few questions while
implementing the code!
Signature:
----------
Sydney Benck
~                                                                                                                                                                                                            
~                                                                                                                                                                                                            
~                                                                                                                                                                                                            
~                                                                                                                                                                                                            
~                                                                                                                                                                                                            
~                                                                                                                                                                                                            
~                                                                                                                                                                                                            
~                                                                                                                                                                                                            
~                                                                                                                                                                                                            
~                                                                                                                                                                                                            
~                                                                                                                                                                                                            
~                                                                                                                                                                                                            
~                                                                                                                                                                                                            
~                                                                                                                                                                                                            
~                                                                                                                                                                                                            
~                                                                                                                                                                                                            
~                                                                                                                                                                                                            
~                                                                                                                                                                                                            
~                                                                                                                                                                                                            
~                                                                                                                                                                                                            
~                                                                                                                                                                                                            
~                                                                                                                                                                                                            
~                                                                                                                                                                                                            
~                                                                                                                                                                                                            
~
