DataWrangler README for Project One (CS400 @ UW Madison)
========================================================
Name of DataWrangler: Jonathon Byrnes
@wisc.edu Email of DataWrangler: jdbyrnes@wisc.edu
Group: GG
Team: Blue
Files Written by Me:
--------------------
Movie.java  (Creates movie objects and contains methods to access their data fied
s)
MovieInterface.java (Interface for the Movie class)
MovieDataReader.java (Reads in movie data from a .csv file and creates a list of 
movie objects based on each line of the .csv file)
MovieDataReaderInterface.java  (Interface for the MovieDataReader class)
Additional Contributions:
-------------------------
Created some test classes to test my own .java files, as well as assisting team m
embers with their code and the implementation of my code with theirs.
Signature:
----------
<Type out your full name here to certify that all of the files written by you
 that are listed above are the product of your individual development efforts
 for this programming assignment.  List below your name, any exceptions, for
 example: work reused from a previous semester, code examples taken from any
 website or book, or anything that was not explicitly authored by you for
 the purpose of completing this assigned CS400 project.>
Jonathon Byrnes
NO EXCEPTIONS
