IntegrationManager README for Project One (CS400 @ UW Madison)
========================================================
Name of IntegrationManager: Anubhav Kumaria
@wisc.edu Email of IntegrationManager: kumaria@wisc.edu
Group: GG
Team: BLUE
Complete List of Files:
-----------------------
Miranda Vescio:
Backend.java
BackendInterface.java
BackEndTester.java
Jonathan Byrnes:
Movies.java
MovieDataReader.java
Sydney Benck:
MovieMapper.java
Anubhav Kumaria
MovieMapper.java
Backend.java
Instructions to Build, Run and Test your Project:
-------------------------------------------------
Give filepath for movies.csv in command line arguments.
Team Member Contributions:
--------------------------
Everyone went above and beyond to finish this project and worked tirelessly around their schedules.
Communication was effective and clear in terms of availability and status updates.
I personally did not have to make a class myself as the integration manager but worked a great deal
with the moviemapper and backend files. I debugged several methods in backend as well as fixed issues
with MovieMapper that the FrontEnd dev could not figure out along with the rest of the team either.
Great team!
Signature:
----------
ANUBHAV KUMARIA
"IntegrationManager_README.txt" [dos] 43L, 1284C     
