BackEndDeveloper README for Project One (CS400 @ UW Madison)
========================================================

Name of BackEndDeveloper: Miranda Vescio
@wisc.edu Email of BackEndDeveloper: mvescio@wisc.edu
Group: GG
Team: Blue

Files Written by Me:
--------------------
Backend.java:
        The class for the Backend Interface which is designed to read in
data from the DataWrangler and pass it on to the Frontend program.
BackendTester.java:
        A class for testing the functionality of the Backend class.
BackendInterface.java:
        The interface implemented in the Backend class.

Additional Contributions:
-------------------------
 I originally reached out to all of my group members (in group GG) via
their emails in order to make a groupchat with them in Snapchat and I've
been actively participating in discussions there when they're pertinent to
me. I also worked over a couple video calls with all the members of my team
to help fix bugs and troubleshoot. Another group memeber created a smaller
Snapchat group with just the Blue Team, as well, and I've utilized that for
communication, too.

Signature:
----------
Miranda Vescio
<Type out your full name here to certify that all of the files written by you
 that are listed above are the product of your individual development efforts
 for this programming assignment.  List below your name, any exceptions, for
 example: work reused from a previous semester, code examples taken from any
 website or book, or anything that was not explicitly authored by you for
 the purpose of completing this assigned CS400 project.>
