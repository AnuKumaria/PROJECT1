# BLUE-PROJECT-1
GIT repo for Blue Group Project 1 - CS 400
