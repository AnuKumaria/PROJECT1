import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.io.File;
import java.io.FileReader;
import java.io.Reader;
import java.util.Scanner;

public class MovieMapper {
  /**
   * This method prints out a welcome message to the user when the app is 
   * started. The arguments passed through this method are then sent to the 
   * base mode method.
   * @param args
   */
  public static void main(String[] args) {
    // File path to the CSV File with the movie information
    BackendDummy movies = new BackendDummy(args);

    // Welcome message
    System.out.println("Welcome to Movie Mapper!");

    // Sends the user to the base mode
    baseMode(movies);    
  }
 
  /**
   * This method represents the Base Mode of the 
   * Movie-Mapper App. The base mode is the mode that the Movie-Mapper will 
   * start in. The base mode starts by displaying a list of the top 3 avg-rated 
   * movies. Then the user is prompted to enter in a command to switch into
   * other modes or exit the app.
   */
  public static void baseMode(BackendDummy movies) {

    System.out.println("Here's a list of our top-rated movies:");

    // Display 3 movies from BackEnd interface
    if(movies.getNumberOfMovies() <= 3) {
      for (int i = 0; i < movies.getNumberOfMovies(); i++) {
        System.out.println(movies.getThreeMovies(i).get(i).getTitle() + " " + 
            movies.getThreeMovies(i).get(i).getAvgVote());
      }
    } else if (movies.getNumberOfMovies() > 3) {
        for (int i = 0; i < 3; i++) {
          System.out.println(movies.getThreeMovies(i).get(i).getTitle());
        } 
    } else if (movies.getNumberOfMovies() == 0) {
        System.out.println("There are no movies in the selection set!");
    }   

    // Takes input from the user
    System.out.println("Scroll through the list by inputing the rating that "
        + "corresponds to the desired movie!");
    System.out.println("Enter 'g' to select a movie based off genre, enter 'r' "
        + "to select a movie based off ratings. Enter 'x' to exit.");

    Scanner input = new Scanner(System.in);

    //integer check
    if (input.hasNextInt()){
      // Puts command into a variable and then gets rid of the extra line left in the scanner
      int command = input.nextInt();
      input.hasNextLine();
      baseScroll(movies, command);
    }

    else {
    String in=input.next();

    if (in.charAt(0)=='g') {
      // Sends user to the genre selection mode
      genreSelectionMode(movies);
    } else if (in.charAt(0)=='r') {
      // Sends user to ratings selection mode
      ratingsSelectionMode(movies);
    } 
    else {
      System.out.println("This input is invalid! Try entering a number 0-10, or"
          + " switching to genre mode (g) or ratings mode (r).");
    }
    input.close();
  }
  }
  
  /**
   * Helper method that allows the user to continuously type in numbers in the 
   * base mode to scroll through the list of movies by their average rating.
   * @param m the list of movies
   * @param rating the rating that was selected by the user as input
   */
  private static void baseScroll(BackendDummy m, int rating) {
    Scanner in = new Scanner(System.in); 
    System.out.println("Here are the movies with a rating equal to or greater than the rating selected:");
    
    for (int i = 0; i < m.getNumberOfMovies(); i++) {
      if (m.getThreeMovies(i).get(i).getAvgVote() >= rating) {
        System.out.println(m.getThreeMovies(i).get(i).getTitle());
      }
    }
    // integer check
    if (in.hasNextInt()) {
      // Throws new command through this method again
      int input = in.nextInt();
      baseScroll(m, input);
    } else  {
      String input = in.next();

      if (input.charAt(0)=='g') {
        // Sends user to the genre selection mode
        genreSelectionMode(m);
      } else if (input.charAt(0)=='r') {
        // Sends user to ratings selection mode
        ratingsSelectionMode(m);
      } 
      else {
        System.out.println("This input is invalid! Try entering a number 0-10, or"
            + " switching to genre mode (g) or ratings mode (r).");
      }
      in.close();
    }
  }
  /**
   * This method allows the user to select and deselect movies based off
   * their genre. If multiple genres are selected, only movies that have all
   * selected genres will be displayed.
   */
  public static void genreSelectionMode(BackendDummy movies) {
    Scanner input = new Scanner(System.in);
    String [] s = null;
    BackendDummy selected = new BackendDummy(s); // Initially empty
    BackendDummy unselected = movies; // Initially contains all genre options
    BackendDummy moviesDisplayed = movies; // Initially no movies are displayed

    // Brief explanation telling the user how to use the genre selection mode
    System.out.println("Select and deselect movies based on their genre by inputting "
        + "its corresponding number listed below!");
    System.out.println("After every entry, the selected and deselected lists will be"
        + "updated and printed out to the screen.");
    System.out.println("Here's all of our genres with their corresponding command numbers: ");

    // Assign every genre to a number and print list
    List<String> list = movies.getAllGenres();
    for (int i = 0; i < list.size(); i++) {
      System.out.println((i+1) + ": " + list.get(i).toString());
    }
    
    // Brief description on how to return to the base mode.
    System.out.println("Return to the home screen by inputing (x).");

    // Initial screen is an empty list otherwise print out contents of both lists
    if (selected.getAllGenres().size() == 0) {
      System.out.println("There are no currently selected genres.");
    } else {
      System.out.println("Here are the genres that are currently selected:");
      System.out.println(selected.getAllGenres().toString());
    }
    
    // Print out unselected movies
    if (unselected.getAllGenres().size() == 0) {
      System.out.println("All genres are currently selected.");
    } else {
      System.out.println("Here are the genres that are currently unselected:");
      System.out.println(unselected.getAllGenres());
    }
    
    // Prompt the user to make a command
    System.out.println("Enter a number to select or unselect a genre!");
    
    // integer check
    if (input.hasNextInt()) {
      // Puts command into a variable
      int command = input.nextInt();
      input.hasNextLine();
      genreSelection(selected, unselected, list, command, moviesDisplayed, movies);
    } else {
      String in=input.next();
      if (in.charAt(0)=='g') {
        // Sends user to the genre selection mode
        genreSelectionMode(movies);
      } else if (in.charAt(0)=='r') {
        // Sends user to ratings selection mode
        ratingsSelectionMode(movies);
      } else if (in.charAt(0) == 'x') {
        baseMode(movies);
      }
      else {
        System.out.println("This input is invalid! Try entering a number that corresponds to a genre, or"
            + " switching to base mode (x) or ratings mode (r).");
      }
      input.close();
    } 
  }
  /**
   * This is a private helper method to the genre selection class. This helper 
   * method allows user to recursively type in commands to select or 
   * un-select desired genres. The method will prompt the user after the user has
   * selected a genre and updated the lists.
   * @param s list of selected genres
   * @param u list of unselected genres
   * @param all list of all of the genres
   * @param command the input from the user that will be switched from one
   * list to the other
   * @param display the movies that are displayed to the screen based off of the 
   * genres that are selected
   */
  private static void genreSelection(BackendDummy s, BackendDummy u, 
    List<String> list, int command, BackendDummy display, BackendDummy movies) {
    
    Scanner in = new Scanner(System.in);
    boolean found = false; // Set to true if found in the selected list.
    
    // Check both lists to locate the genre and then move the genre to the other list
    if (s.getAllGenres().size() == 0) {
      s.addGenre(list.get(command-1));
      u.removeGenre(list.get(command-1).toString());
    } else {
      for (int i = 0; i < s.getAllGenres().size(); i++) {
        if (s.getGenres().get(i).equals(list.get(command-1))) {
          s.removeGenre(list.get(command -1));
          u.addGenre(list.get(command-1).toString());
          found = true;
        }
      }
    }
    if (!found) {
      for (int i = 0; i < u.getAllGenres().size(); i++) {
        if (u.getAllGenres().get(i).equals(list.get(command-1))) {
          u.removeGenre(list.get(command-1));
          s.addGenre(list.get(command-1).toString());
        }
      }
    }
    
    // Now that the lists are updated, print them out
    System.out.println("Here are the genres that are currently selected:");
    System.out.println(s.getAllGenres());
    System.out.println("Here are the genres that are currently unselected:");
    System.out.println(u.getAllGenres());
    
    // Find all of the movies that have the genres that are selected
    System.out.println("Movies based off of the genres that are selected:");
    for (int i = 0; i < display.getNumberOfMovies(); i++) {
      for (int j = 0; j < s.getAllGenres().size(); j++) {
        if (display.getGenres().equals(s.getAllGenres())) {
          System.out.println(display.getThreeMovies(j).get(j).getTitle());
        }
      }
    }
    
    // Prompt the user to enter input again
    System.out.println("Enter in another number that corresponds to a genre, or "
        + "exit back to the base mode (x).");
    // Integer check
    if (in.hasNextInt()) {
      int userInput = in.nextInt();
      genreSelection(s, u, list, userInput, display, movies);
    } else {
      String input = in.next();
      if (input.charAt(0)=='g') {
        // Sends user to the genre selection mode
        genreSelectionMode(movies);
      } else if (input.charAt(0)=='r') {
        // Sends user to ratings selection mode
        ratingsSelectionMode(movies);
      } else if (input.charAt(0) == 'x') {
        // Sends user to base mode
        baseMode(movies);
      }
      else {
        System.out.println("This input is invalid! Try entering a number that corresponds to a genre, or"
            + " switching to base mode (x) or ratings mode (r).");
      }
      in.close();
    }
  }
  /**
   * This method allows users to select a movie based off of their ratings.
   * Initially all ratings are selected. Users can deselect and select any 
   * ratings that are in the list. The ratings are in the range [0-10] where
   * 0 is the worst rating and 10 is the highest. When a rating is selected 
   * all movies that have this rating (ignoring the decimal point) will 
   * be selected. For example, selecting 8 will select all movies from 8.0 to 8.999.
   */
  public static void ratingsSelectionMode(BackendDummy movies) {
    Scanner input = new Scanner(System.in);
    // Initial list of deselected movies does not contain anything
    String [] in = null;
    BackendDummy deselected = new BackendDummy(in);
    BackendDummy selected = movies;

    // Prompt User
    System.out.println("Select a movie based off its rating by entering a number"
        + " that represents the rating of the movies you would like to pick from.");
    System.out.println("You can de-select and re-select ratings from the list below!");
    // Let the user know which ratings they can select
    for (int i = 0; i <= 10; i++) {
      System.out.println("[" + i + "]");
    }
    
    // Collect input from user
      String command = input.next();
      // Sends the user to the helper method that recursively checks for new ratings
      ratingSelection(command, movies, selected, deselected);


    System.out.println("Ratings currently selected:");
    for (int i = 0; i < movies.getAvgRatings().size(); i++) {
      System.out.println(movies.getAvgRatings().get(i).toString());
    }
    System.out.println("Ratings not currently selectd:");
    if (deselected.getAvgRatings().size() == 0) {
      System.out.println("All ratings are currently selected.");
    } else {
      System.out.println(deselected.toString());
    }
  }
  /**
   * This helper method takes a rating that is selected and searches for all of
   * the movies that are in this movie selection set that match that rating.
   * This helper method allows the user to input ratings over and over again 
   * until they find the preferred rating.
   * @param r rating that is inputed by the user.
   * @param s total movies
   * @param de-selected ratings
   * @param selected ratings
   */
  private static void ratingSelection(String r, BackendDummy m, BackendDummy s, BackendDummy d) {
    // Search through each list and then either add the user input to the 
    // selected or de-selected list depending on where the input number is found.
    boolean found = false;
    for (int j = 0; j < s.getAvgRatings().size(); j++) {
      if (s.getAvgRatings().get(j).equals(r)) {
        found = true;
        s.removeAvgRating(r);
        d.addAvgRating(r);
      } else if (!found) {
        for (int i = 0; i < d.getAvgRatings().size(); i++) {
          if (r.equals(d.getAvgRatings().get(i))) {
            d.removeAvgRating((String) r);
            s.addAvgRating(r.toString());
          }
        }
      }
    }
    
    // Print out new lists
    System.out.println("Ratings currently selected:");
    for (int i = 0; i < s.getAvgRatings().size(); i++) {
      System.out.println(s.getAvgRatings().get(i).toString());
    }
    System.out.println("Ratings not currently selectd:");
    if (d.getAvgRatings().size() == 0) {
      System.out.println("All ratings are currently selected.");
    } else {
      System.out.println(d.getAvgRatings().toString());
    }
    
    // Re-prompt the user
    // Collect input from user
    System.out.println("Enter a new rating or (x) to exit and go back to base mode.");
    Scanner in = new Scanner(System.in);
    
    // Integer check
    if (in.hasNextInt()) {
      String command = in.next();
      // Sends the user to the helper method that recursively checks for new ratings
      ratingSelection(command, m, s, d);
    } else {
    String input = in.next();
    if (input.charAt(0)=='g') {
      // Sends user to the genre selection mode
      genreSelectionMode(m);
    } else if (input.charAt(0)=='r') {
      // Sends user to ratings selection mode
      ratingsSelectionMode(m);
    } else if (input.charAt(0) == 'x') {
      // Sends user to base mode
      baseMode(m);
    }
    else {
      System.out.println("This input is invalid! Try entering a number that corresponds to a genre, or"
          + " switching to base mode (x) or ratings mode (r).");
    }
    in.close();
  }
  }
}
